window.MG = {version: '2.5.0'};
