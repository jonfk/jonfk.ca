module.exports = require('./dist/metricsgraphics');
